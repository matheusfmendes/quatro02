
public interface ObjetoGeometrico {
	Ponto2D centro();
	double calculaArea();
	double calculaPerimetro();
	
}
