
public class Ponto2D {
	private double x, y;

	public Ponto2D(double coordX, double coordY) {
		
	}

	public void inicializaPonto2D(double X, double Y) {
		setX(X);
		setY(Y);
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

}
