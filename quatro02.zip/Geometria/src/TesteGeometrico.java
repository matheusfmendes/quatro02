import java.util.Scanner;

public class TesteGeometrico {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		Quadrado q = new Quadrado(2, 2);
		
		System.out.println(+q.calculaArea());
		
		

	}

}
